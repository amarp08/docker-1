#!/bin/bash
#Initializing two variables 
#a=Akas
#b=Akas

read a
read b


#Check whether they are equal 

if [ $a == $b ] 

then 

    echo "Names are same"


else

    echo "different"

fi 
