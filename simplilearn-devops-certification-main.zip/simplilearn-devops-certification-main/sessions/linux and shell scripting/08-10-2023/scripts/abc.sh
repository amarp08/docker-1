#!/bin/bash
#echo "My test line"
HI=Hello
echo HI
echo $HI
echo "$HI"
echo '$HI'
echo "#HIAKAS"
echo `pwd`
echo $(pwd)
