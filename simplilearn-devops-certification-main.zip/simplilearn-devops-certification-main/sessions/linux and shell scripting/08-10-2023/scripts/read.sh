#!/bin/bash
echo "what is ur name?"
read name
echo "hello $name"

echo " what is ur age?"
read age
print "I am $age years old"
