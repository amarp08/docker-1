#!/bin/bash

#Define your function
# function Hello (){
#     echo "Hello World"
# }

Hello (){
    echo "Hello World"
}

# Invoke your function
Hello