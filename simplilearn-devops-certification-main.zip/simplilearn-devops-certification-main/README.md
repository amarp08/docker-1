# simplilearn-devops-certification
simplilearn-devops-certification class notes
